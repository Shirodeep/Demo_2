import React from 'react'

const About = () => {
  return (
    <div>
      wadsfgvnb
    </div>
  )
}

export default About
